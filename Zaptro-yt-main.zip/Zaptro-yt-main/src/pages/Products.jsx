import React, { useEffect, useState } from 'react';
import axios from 'axios';
import FilterSection from '../components/FilterSection';
import Loading from "../assets/Loading4.webm";
import ProductCard from '../components/ProductCard';
import Pagination from '../components/Pagination';
import Lottie from 'lottie-react';
import notfound from "../assets/notfound.json";
import MobileFilter from '../components/MobileFilter';

const Products = () => {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [brand, setBrand] = useState("All");
  // Also update the price range to accommodate your product's price (6500)
  const [priceRange, setPriceRange] = useState([0, 10000]); // Increased from 5000 to 10000
  const [page, setPage] = useState(1);
  const [openFilter, setOpenFilter] = useState(false);
  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch products once on mount
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await axios.get('http://localhost:3001/api/products');
        console.log("Raw API Response:", res);
        console.log("Response Data:", res.data);
        console.log("Data Type:", typeof res.data);
        console.log("Is Array:", Array.isArray(res.data));
        console.log("Data Length:", res.data?.length);
        
        // Handle different response structures
        let productsData = res.data;
        if (res.data && res.data.products) {
          productsData = res.data.products;
        } else if (res.data && res.data.data) {
          productsData = res.data.data;
        }
        
        console.log("Final Products Data:", productsData);
        setProducts(Array.isArray(productsData) ? productsData : []);
      } catch (err) {
        console.error("Error fetching products:", err);
        setError("Failed to fetch products.");
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  // Filter change handlers
  const handleCategoryChange = (e) => {
    setCategory(e.target.value);
    setPage(1);
    setOpenFilter(false);
  };

  const handleBrandChange = (e) => {
    setBrand(e.target.value);
    setPage(1);
    setOpenFilter(false);
  };

  const pageHandler = (selectedPage) => {
    setPage(selectedPage);
    window.scrollTo(0, 0);
  };

  // Enhanced filter logic with correct field names and better debugging
  const filteredData = products.filter((item) => {
    // Use 'name' instead of 'title' since that's what your API returns
    const matchesSearch = !search || item.name?.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === "All" || 
      item.category?.toLowerCase() === category.toLowerCase();
    const matchesBrand = brand === "All" || item.brand === brand;
    
    // Convert price string to number for comparison
    const itemPrice = parseFloat(item.price) || 0;
    const matchesPrice = itemPrice >= priceRange[0] && itemPrice <= priceRange[1];
    
    // Debug logging for ALL products to see categories
    console.log("Product filter debug:", {
      productName: item.name,
      productCategory: item.category,
      selectedCategory: category,
      productBrand: item.brand,
      selectedBrand: brand,
      productPrice: itemPrice,
      priceRange,
      matchesSearch,
      matchesCategory,
      matchesBrand,
      matchesPrice,
      finalMatch: matchesSearch && matchesCategory && matchesBrand && matchesPrice
    });
    
    return matchesSearch && matchesCategory && matchesBrand && matchesPrice;
  });

  const dynamicPage = Math.ceil(filteredData.length / 8);

  // Debug logging
  console.log("Products state:", products);
  console.log("Filtered data:", filteredData);
  console.log("Current filters:", { search, category, brand, priceRange });
  
  // Log all unique categories and brands for debugging
  const allCategories = [...new Set(products.map(p => p.category))];
  const allBrands = [...new Set(products.map(p => p.brand))];
  console.log("Available categories:", allCategories);
  console.log("Available brands:", allBrands);

  // Loading state
  if (loading) {
    return (
      <div className='flex items-center justify-center h-[400px]'>
        <video muted autoPlay loop>
          <source src={Loading} type='video/webm' />
        </video>
      </div>
    );
  }

  // Error state
  if (error) {
    return <div className="text-red-500 text-center p-10">{error}</div>;
  }

  return (
    <div>
      <div className='max-w-6xl mx-auto px-4 mb-10'>
        <MobileFilter
          openFilter={openFilter}
          setOpenFilter={setOpenFilter}
          search={search}
          setSearch={setSearch}
          brand={brand}
          setBrand={setBrand}
          priceRange={priceRange}
          setPriceRange={setPriceRange}
          category={category}
          setCategory={setCategory}
          handleCategoryChange={handleCategoryChange}
          handleBrandChange={handleBrandChange}
        />

        {/* Always show the filter and product area if products are loaded */}
        <div className='flex gap-8'>
          <FilterSection
            search={search}
            setSearch={setSearch}
            brand={brand}
            setBrand={setBrand}
            priceRange={priceRange}
            setPriceRange={setPriceRange}
            category={category}
            setCategory={setCategory}
            handleCategoryChange={handleCategoryChange}
            handleBrandChange={handleBrandChange}
          />

          {filteredData.length > 0 ? (
            <div className='flex flex-col justify-center items-center'>
              <p className="text-green-600 mb-4">Found {filteredData.length} products</p>
              <div className='grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-7 mt-10'>
                {filteredData
                  .slice((page - 1) * 8, page * 8)
                  .map((product, index) => {
                    console.log("Rendering product:", product);
                    return <ProductCard key={product.id || index} product={product} />;
                  })}
              </div>
              {dynamicPage > 1 && (
                <Pagination
                  pageHandler={pageHandler}
                  page={page}
                  dynamicPage={dynamicPage}
                />
              )}
            </div>
          ) : (
            <div className='flex flex-col justify-center items-center md:h-[600px] md:w-[900px] mt-10'>
              <p className="text-red-600 mb-4">
                No products found. Total products in state: {products.length}
              </p>
              {products.length === 0 ? (
                <div className='text-center'>
                  <p>No products available from API</p>
                </div>
              ) : (
                <div className="text-center">
                  <Lottie animationData={notfound} className='w-[500px]' />
                  <p>All products filtered out</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Products;